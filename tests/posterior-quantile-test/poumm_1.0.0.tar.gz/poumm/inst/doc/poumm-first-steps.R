## ----setup, include = FALSE----------------------------------------------
# Make results reproducible
set.seed(1)
library(ggplot2)
library(data.table)
knitr::opts_chunk$set(cache = FALSE)
options(digits = 4)

## ----install, eval=FALSE-------------------------------------------------
#  install.packages('poumm_1.0.0.tgz', type='binary', repos=NULL)
#  install.packages("TreeSim")
#  install.packages("data.table")
#  install.packages("ggplot2")

## ------------------------------------------------------------------------
N <- 500
g0 <- 0           
alpha <- .5        
theta <- 2        
sigma <- 0.2     
sigmae <- 0.2 

## ---- echo=FALSE, fig.height=4.6, fig.width=7, fig.cap="Dashed black and magenta lines denote the deterministic trend towards the long-term mean $\\theta$, fixing the stochastic parameter $\\sigma=0$."----
tStep <- 0.025
t <- seq(0, 6, by = tStep)

plot(t, poumm::rTrajectoryOU(g0, tStep, alpha, theta, sigma, length(t)), type = 'l', main = "Random OU trajectories", ylab = "g", ylim = c(0, 4))
lines(t, poumm::rTrajectoryOU(g0, tStep, alpha, theta, 0, length(t)), lty = 2)

lines(t, poumm::rTrajectoryOU(g0, tStep, alpha*2, theta, sigma, length(t)), col = "magenta")
lines(t, poumm::rTrajectoryOU(g0, tStep, alpha*2, theta, 0, length(t)), lty = 2, col = "magenta")

lines(t, poumm::rTrajectoryOU(g0, tStep, alpha, theta, sigma*2, length(t)), col = "blue")

abline(h=theta, lty = 3, col = "darkgrey")

legend("topleft", 
       legend = c(expression(list(alpha == .5, theta == 2, sigma == 0.2)),
                  expression(list(alpha == .5, theta == 2, sigma == 0.4)),
                  expression(list(alpha == .5, theta == 2, sigma == 0)),
                  
                  expression(list(alpha == 1, theta == 2, sigma == 0.2)),
                  expression(list(alpha == 1, theta == 2, sigma == 0)),
                  
                  expression(theta == 2)),
       lty = c(1, 1, 2, 1, 2, 3), 
       col = c("black", "blue", "black", "magenta", "magenta", "darkgrey"))

## ----simulate-tree, results="hide"---------------------------------------
# Number of tips
tree <- TreeSim::sim.bdsky.stt(N, lambdasky = 1.6, deathsky = .6, 
                               timesky=c(0, Inf), sampprobsky = 1)[[1]]

## ----simulate-gez-OU-----------------------------------------------------
# genotypic (heritable) values
g <- poumm::rVNodesGivenTreePOUMM(tree, g0, alpha, theta, sigma)

# environmental contributions
e <- rnorm(length(g), 0, sigmae)

# phenotypic values
z <- g + e

## ----violin-plots, fig.show = "hold", fig.height=4, fig.width=7----------
# This is easily done using the nodeTimes utility function in combination with
# the cut-function from the base package.
data <- data.table(z = z[1:N], t = poumm::nodeTimes(tree, tipsOnly = TRUE))
data <- data[, group := cut(t, breaks = 5, include.lowest = TRUE)]

ggplot(data = data, aes(x = t, y = z, group = group)) + 
  geom_violin(aes(col = group)) + geom_point(aes(col = group), size=.5)

## ----colored-tree-plots, fig.show = "hold", fig.height=4, fig.width=7----
# This is easily done using the nodeTimes utility function in combination with
# the cut-function from the base package.
phytools::plotBranchbyTrait(tree, z, mode = "nodes", 
                            show.tip.label = FALSE, show.node.label = FALSE) 

## ----fitPOUMM-1, eval=TRUE-----------------------------------------------
# set up a parallel cluster on the local computer for parallel MCMC:
cluster <- parallel::makeCluster(parallel::detectCores(logical = FALSE))
doParallel::registerDoParallel(cluster)

fitPOUMM <- poumm::POUMM(z[1:N], tree, spec = list(parallelMCMC = TRUE))

# Don't forget to destroy the parallel cluster to avoid leaving zombie worker-processes.
parallel::stopCluster(cluster)

## ---- fig.height=4, fig.show="hold", fig.width=7, warning=FALSE----------
plot(fitPOUMM, interactive = FALSE)

## ---- warning=FALSE------------------------------------------------------
summary(fitPOUMM)

## ----fitPOUMM-2, eval=TRUE-----------------------------------------------
cluster <- parallel::makeCluster(parallel::detectCores(logical = FALSE))
doParallel::registerDoParallel(cluster)

fitPOUMM2 <- poumm::POUMM(z[1:N], tree, doMCMC = TRUE, spec=list(nSamplesMCMC = 4e5, parallelMCMC = TRUE))  

parallel::stopCluster(cluster)

## ---- fig.height=4, fig.show="hold", fig.width=7, warning=FALSE----------
plot(fitPOUMM2, interactive = FALSE)

## ---- warning=FALSE------------------------------------------------------
summary(fitPOUMM2)

## ------------------------------------------------------------------------
tMean <- mean(poumm::nodeTimes(tree, tipsOnly = TRUE))
tMax <- max(poumm::nodeTimes(tree, tipsOnly = TRUE))

c(# phylogenetic heritability at mean root-tip distance: 
  H2tMean = poumm::H2(alpha, sigma, sigmae, t = tMean),
  # phylogenetic heritability at long term equilibirium:
  H2tInf = poumm::H2(alpha, sigma, sigmae, t = Inf),
  # empirical (time-independent) phylogenetic heritability, 
  H2e = poumm::H2e(z[1:N], sigmae),
  # genotypic variance at mean root-tip distance: 
  sigmaG2tMean = poumm::varOU(t = tMean, alpha, sigma),
  # genotypic variance at max root-tip distance: 
  sigmaG2tMean = poumm::varOU(t = tMax, alpha, sigma),
  # genotypic variance at long-term equilibrium:
  sigmaG2tInf = poumm::varOU(t = Inf, alpha, sigma)
  )

## ---- warning=FALSE------------------------------------------------------
c(H2empirical = var(g[1:N])/var(z[1:N]))
summary(fitPOUMM2)["H2tMean"==stat, unlist(HPD)]

