# bijection NxN->N
cantorPairingNumber <- function(a, b, ordered=TRUE) {
  a <- as.integer(a)
  b <- as.integer(b)
  if(!ordered) {
    c <- a
    c[a>b] <- b[a>b]
    b[a>b] <- a[a>b]
    a <- c
  }
  ((a+b)*(a+b+1)/2+b)
}


#' Extract tip pairs from a phylogeny.
#' @param tree a phylo object
#' @param threshold numeric indicating the maximum pair distance that should be allowed in the returned pairs
#' @param firstN integer indicating whether only the nearest firstN pairs should be returned
#' @return a data.table with four columns:
#' i, j : integers - the members of each tip-pair. For each entry (i,j) a symmetric entry (j,i) is present;
#'    to obtain the corresponding tip labels in the tree use tree$tip.label[i] and tree$tip.label[j] respectively.
#' tau: the phylogenetic distance between i and j
#' idPair: the unique identifier of each pair.
#' 
#' 
#' @export
extractTipPairs <- function(tree, threshold=Inf, firstN=Inf) {
  N <- length(tree$tip.label)
  tipDists <- ape::dist.nodes(tree)[1:N, 1:N]
  diag(tipDists) <- Inf
  pairs <- data.table::as.data.table(do.call(rbind, lapply(1:N, function(i) {
    cbind(i, (1:N)[-i], tipDists[i, -i])
  })))
  setnames(pairs, c('i', 'j', 'tau'))
  pairs[, idPair:=cantorPairingNumber(i, j, ordered=FALSE)]
  if(!is.infinite(threshold)) {
    pairs[tau<=threshold][order(idPair)]
  } else if(!is.infinite(firstN)) {
    pairs[tau<=order(tau)[min(length(tau), firstN)]][order(idPair)]
  } else {
    pairs[order(idPair)]
  }
}

#' Extract phylogenetic pairs from a phylogeny or mutually closest pairs from a distance matrix.
#' @param tree a phylo object; Can be left NULL, in which case the tipDists matrix should be specified;
#' @param tipDists a N by N numeric matrix containing the tip-distances in the tree; can be NULL, in which
#' case it is going to be calculated; if specified, the tree-parameter will only be used for calculation
#' of vcvMat and no validation of tip-distances in the tree with the tipDists matrix will be done.
#' @param threshold numeric indicating the maximum pair distance that should be allowed in the returned pairs
#' @param firstN integer indicating whether only the nearest firstN pairs should be returned
#' @param vcvMat a N by N matrix where N is the number of tips in the tree. The diagonal elements of this
#' matrix represent the root-tip distances; the off-diagonal elements represent the distance from the
#' root to the most recent common ancestor of each couple of tips. This matrix is calculated by the 
#' vcv function from the ape package. If tree is specified, the matrix can be specified only for the 
#' sake of saving calculation time when a call to vcv has already been executed on the tree; 
#' If the tree is not specified (i.e. a tipDists-matrix is given), then it is assumed that the tree is 
#' ultrametric with length equal to t=max(tipDists)/2 and vcvMat[i,j] is calculated as 
#' vcvMat[i,j]=t-tipDists[i,j]/2.
#' @param z (optional, defaults to NULL) a numeric vector with phenotypes corresponding to the tips in tree
#' or the row numbers in tipDists. 
#' @return a data.table with five columns:
#' i, j : integers - the members of each phylogenetic pair. For each entry (i,j) a symmetric entry (j,i) is present; 
#'    to obtain the corresponding tip labels in the tree use tree$tip.label[i] and tree$tip.label[j] respectively.
#' tau: the phylogenetic distance between i and j
#' t: the root-tip distance of the mrca of i and j
#' idPair: the unique identifier of each pair
#' z: the value corresponding to each i 
#' (this column doesn't exist if no parameter z is specified)
#' deltaz: the absolute phenotypic distance between members of a pair 
#' (this column doesn't exist if no parameter z is specified)
#' 
#' @details Phylogenetic pairs represent pairs of tips each of which is the other's nearest neighbor-tip in
#' the phylogenty according to patristic (phylogenetic distance)
#' 
#' @export
extractPP <- function(tree=NULL, tipDists=NULL, threshold=Inf, firstN=Inf, 
                      vcvMat=NULL,
                      z=NULL) {
  if(!is.null(tipDists)) {
    if(ncol(tipDists)!=nrow(tipDists)) {
      stop('tipDists is not a square matrix.')
    }
    N <- nrow(tipDists)
    names <- rownames(tipDists)
    if(is.null(tree)) {
      if(is.null(vcvMat)) {
        # assuming ultrametric tree of length max(tipDists)/2
        vcvMat <- max(tipDists)/2-tipDists/2
      }
    } else {
      if(is.null(vcvMat)) {
        vcvMat <- ape::vcv(tree)
      }
    }
  } else {
    if(is.null(tree)) {
      stop('Parameter tree has to be specified in case of NULL tipDists.')
    }
    N <- length(tree$tip.label) 
    names <- tree$tip.label
    if(is.null(vcvMat)) {
      vcvMat=ape::vcv(tree)
    }
  }
  
  ttips <- diag(vcvMat)
  pairs <- t(sapply(1:N, function(i) {
    vcvMati <- vcvMat[, i]
    if(is.null(tipDists)) {
      tipDistsi <- ttips[i]+ttips-2*vcvMati
    } else {
      tipDistsi <- tipDists[i, ]
    }
    
    tipDistsi[i] <- Inf  
    j <- which.min(tipDistsi)[1]; 
    c(i, j, tipDistsi[j], vcvMat[i,j])
  }))
  colnames(pairs) <- c('i', 'j', 'tau', 't')
  pp <- data.table(i=as.integer(pairs[, 'i']), j=as.integer(pairs[, 'j']), 
                   tau=pairs[, 'tau'], t=pairs[, 't'], 
                   idPair=apply(pairs, 1, function(p) {
                     if(p['i'] == pairs[p['j'], 'j']) {
                       cantorPairingNumber(p['i'], p['j'], ordered=FALSE)
                     } else {
                       NA
                     }
                   }),
                   i.name=names[pairs[, 'i']])[!is.na(idPair)]
  
  if(!is.null(z)) {
    if(length(z)!=N) {
      stop('the size of z is different from the number of tips.')
    }
    pp[, z:=z[i]]
    pp[, deltaz:=abs(z[1]-z[2]), by=idPair]
  }
  
  if(!is.infinite(threshold)) {
    pp[tau<=threshold][order(idPair)]
  } else if(!is.infinite(firstN)) {
    pp[tau<=order(tau)[min(length(tau), firstN)]][order(idPair)]
  } else {
    pp[order(idPair)]
  }
}


#' Bootstrap ANOVA 
#' @param i integer vector identifiers of the individuals
#' @param idPair integer vector showing the membership of individuals in pairs or bigger classes
#' @param z numeric vector of phenotypes
#' @param bootstraps integer the number of bootstrap samples to perform (default 1000)
#' @return list iwth estimated rA and 95% confidence intervals
#' @details the function performs 1000 bootstraps
#' 
#' @import data.table 
#' @import boot
#' 
#' @export
rAboot <- function(i, idPair, z, bootstraps=1000, as.dt=FALSE, ...) {
  stats <- c('rA', 'sigmaG2', 'sigmae2', 'F')
  if(length(z) < 2) {
    if(as.dt) {
      return(data.table(stat=stats,
                        N=length(z), 
                        K=length(z)/2,
                        n=2,
                        est=rep(NA, length(stats)),
                        bCI=lapply(1:length(stats), function(i) c(NA, NA)),
                        tips=list(i),
                        bSample=lapply(1:length(stats), function(i) numeric()),
                        ...))
    } else {
      return(list(tips=list(i), bootstrap=NULL, 
                  bCI95lower=NA,
                  bCI95upper=NA,
                  rA=NA, 
                  CI95lower=NA, CI95upper=NA, 
                  sigma2G=NA, sigma2z=NA, n=NA, 
                  N=length(z), K=0))
    }
  } else {
    data <- data.table(gene=idPair, z)
    
    aovReport=rA(data=data, report=TRUE, includePop=FALSE)
    
    if(bootstraps>0)  {
      bootstrap <- boot::boot(data=data[, unique(gene)], statistic=function(idPP, ids) {
        unlist(rA(data=data[gene%in%idPP[ids]], report=TRUE, 
                  includePop=FALSE)[stats])
      }, R=bootstraps)  
      
      bCI <- try(boot::boot.ci(bootstrap, type='basic'), silent=TRUE) 
      
      bCI95lower <- ifelse(class(bCI)!='try-error'&is.list(bCI), bCI$basic[4], NA)
      bCI95upper <- ifelse(class(bCI)!='try-error'&is.list(bCI), bCI$basic[5], NA)
    } else {
      bootstrap <- NULL
      bCI <- NULL
      bCI95lower <- bCI95upper <- NA
    }
    
    
    if(as.dt) {
      data.table(stat=stats, 
                 N=aovReport$N, 
                 K=aovReport$K,
                 n=aovReport$n0,
                 est=unlist(aovReport[stats]),
                 CI=list(c(aovReport$CI95lower, aovReport$CI95upper),
                         c(NA, NA), c(NA, NA), c(NA, NA)),
                 bCI=lapply(1:length(stats), function(i) {
                   if(is.list(bootstrap)) {
                     bCI <- try(boot::boot.ci(bootstrap, type='basic', index=i), silent=TRUE) 
                     bCI95lower <- ifelse(class(bCI)!='try-error' & is.list(bCI), 
                                          bCI$basic[4], NA)
                     bCI95upper <- ifelse(class(bCI)!='try-error'&is.list(bCI), 
                                          bCI$basic[5], NA)
                     c(bCI95lower, bCI95upper)  
                   } else {
                     c(NA, NA)
                   }
                 }),
                 tips=list(i),
                 bSample=lapply(1:length(stats), function(i) {
                   if(is.list(bootstrap)) {
                     bootstrap$t[,i]  
                   } else {
                     NULL
                   }
                 }),
                 ...)
    } else {
      list(tips=list(i), bootstrap=list(bootstrap),
           bCI95lower=bCI95lower,
           bCI95upper=bCI95upper,
           rA=aovReport$H2aov, 
           CI95lower=aovReport$CI95lower, 
           CI95upper=aovReport$CI95upper, 
           sigma2G=aovReport$sigma2G, 
           sigma2z=aovReport$sigma2G+aovReport$sigma2E, 
           n=aovReport$n0, 
           N=aovReport$N, K=aovReport$K)    
    }
  }
}

#' Perform phylogenetic pair analysis
#' @param exclude a data.table specifying selection filters to be applied after 
#' the extraction of phylogenetic pairs. Every row specifies one such filter in
#' the form of R-expressions to be evaluated within the data.table of 
#' extracted phylogenetic pairs (see exctractPP for the description of columns 
#' available in one such data.table). For each row in the pp-table, for which
#' an expression evaluates to TRUE, the corresponding phylogenetic pair rows 
#' (the row itself and its partner row) get removed from the ANOVA analysis. 
#' The exclude data.table has three character vector columns as follows: 
#' name - meaningful name of the filter used as an index (key) in the data.table, 
#' scopeAll - R-expression  evaluated before grouping by quantiles of tau.
#' scopeTau - R-expression evaluated within each tau-quantile group. 
#' Note that the filters are applied on the pp data.table or after a call to 
#' extractPP, so they cannot affect the formation of phylogenetic pairs. Note 
#' also that if a member of a phylogenetic pair gets excluded its 
#' pair-partner is also removed even if the filter expression does not evaluate 
#' to TRUE for it. For example the filter 
#' filters=data.table(name=c('all', 'no outliers in deltaz'), 
#'                    scopeAll=('FALSE'), 
#'                    scopeTau=c('FALSE', 
#'                               'deltaz>\{q=quantile(deltaz); q[4]+1.5*(q[4]-q[2])\}'),
#'                    key='name') 
#' would result in a PP analysis on all phylogenetic pairs, and a PP analysis on
#' the phylogenetic pairs which's phenotypic distance deltaz doesn't exceed 
#' .75%+1.5*IQR of deltazs within each tauQuantile group. By default, no 
#' filtering is done.
#' 
#' @return a data.table with the estimated statistics for each tauQuantile (and filter).
#' 
#' @export
PP <- function(z, tree=NULL, dists=NULL, pp=NULL, seed=10, 
               zName='z', treeName='tree', distsName='dists',
               tauQuantiles=c(V=.05, D=.1, O=.125, qu=.2, Q=.25, M=.5, A=1),
               bootstraps=0, 
               exclude=data.table(name=c('all'), 
                                  scopeAll=c('FALSE'), 
                                  scopeTau=c('FALSE'), 
                                  key='name'),
               verbose=FALSE) {
  if(is.list(z)) {
    p <- z
    z <- p[[zName]]
    if(is.null(z)) {
      z <- p[['v']]
    }
    tree <- p[[treeName]]
    dists <- p[[distsName]]
    
    if(is.null(z)|(is.null(tree)&is.null(dists)&is.null(pp))) {
      stop('If a list is supplied as argument z, this list should contain a 
           vector of trait values named "z" or zName and either a phylo-object 
           named "tree" or treeName or a dists matrix named "dists" or 
           distsName.')
    }
    }
  
  if(is.null(z)) {
    if(is.null(pp)) {
      stop('If z is NULL, pp should be supplied.')
    } else {
      z <- pp[, z]
    }
  } 
  
  if(!is.null(dists)) {
    if(ncol(dists)!=nrow(dists)) {
      stop('dists is not a square matrix.')
    }
    N <- nrow(dists)
    #names(z) <- rownames(dists)
  } else if(!is.null(tree)) {
    N <- length(tree$tip.label)
    #names(z) <- tree$tip.label
  }
  
  if(any(is.na(z))|any(is.nan(z))) {
    stop('NAs or NaNs found in z.')
  }
  
  if(is.null(exclude) | !is.data.table(exclude)) {
    exclude <- data.table(name=c('all'), 
                          scopeAll=c('TRUE'), 
                          scopeTau=c('TRUE'), 
                          key='name')
    warning('Incorrectly specified filter; Using default filtering.')
  } else if(is.data.table(exclude)) {
    if(!setequal(names(exclude), c('name', 'scopeAll', 'scopeTau'))) {
      stop('The column names in exclude should be "name", "scopeAll", "scopeTau".')
    }
  }
  
  if(is.null(pp)) {
    pp <- extractPP(tree=tree, tipDists=dists, z=z)
    setkey(pp, i)
  }
  
  if(!is.na(seed)) {
    set.seed(seed)
  }
  
  res <- list()
  res$tree <- tree
  res$z <- z
  
  if(!is.null(tree)) {
    res$N <- length(tree$tip.label) 
  } else if(!is.null(dists)) {
    res$N <- nrow(dists)
  }
  
  stats <- rbindlist(
    lapply(names(tauQuantiles), function(Qname) {
      if(verbose){
        cat(Qname, '...\n')
      }
      probs=seq(0, 1, by=tauQuantiles[Qname])
      pp[, paste0(Qname, 'tau'):={
        quants=quantile(tau, probs=probs)
        if(length(unique(quants))==1) {
          quants[1] <- .999*quants[1]
        }
        lower=names(quants)[match(unique(quants), quants)]
        upper=names(quants)[length(quants)-match(unique(quants), rev(quants))+1]
        labels=paste0(Qname,c('[', rep('(', length(lower)-2)),
                      lower[1:(length(lower)-1)],',',upper[2:length(upper)],']')
        
        cut(tau, breaks=unique(quants), labels=labels, include.lowest=TRUE)
      }]
      pp[, tauQuantile:=eval(parse(text=paste0(Qname, 'tau')))]
      
      dt <- rbindlist(lapply(exclude[, name], function(flt) {
        if(verbose) {
          cat('Processing filter', flt, '...\n')
        }
        pp[{
          exclude1 <- eval(parse(text=exclude[J(flt), scopeAll]))
          excludeIds1 <- unique(c(i[exclude1], j[exclude1]))
          !(i%in%excludeIds1)
        }, 
        .SD[{
          exclude2 <- eval(parse(text=exclude[J(flt), scopeTau]))
          excludeIds2 <- unique(c(i[exclude2], j[exclude2]))
          !(i%in%excludeIds2)
        }, rAboot(i.name, idPair, z, bootstraps=bootstraps, as.dt=TRUE, 
                  filter=flt, 
                  tauMean=mean(tau), tauMedian=median(tau), 
                  tMean = mean(t), tMedian=median(t),
                  deltazMean=mean(deltaz), deltazMedian=median(deltaz))], 
        keyby=tauQuantile]
      }))
      pp[, tauQuantile:=NULL]
      if(verbose) {
        print(dt)
      }
      dt
    }))
  
  res$pp <- pp
  res$tauQuantiles <- tauQuantiles
  res$seed <- seed
  #res$ruleOutXIQR <- ruleOutXIQR
  res$exclude <- exclude
  res$bootstraps <- bootstraps
  
  res$stats <- stats
  
  class(res) <- c('PP', class(res))
  res
    }

#' Summarize the results of a PP-call in a data.table
#' @return a data.table containing the rA, sigma2G, sigma2e and F-statistics for
#' each quantile-region of the phylogenetic distance tau analyzed in the PP-call.
#' 
#' @import data.table
#' 
#' @export
summary.PP <- function(object) {
  stats <- copy(object$stats)
  stats[, tauQuantileType:=factor(
    regmatches(as.character(tauQuantile), 
               regexpr('^[^\\[\\(]+', as.character(tauQuantile), perl=TRUE)),
    levels=c('V', 'D', 'O', 'qu', 'Q', 'M', 'A'))]
  
  if(is.null(stats[['CI']])) {
    # In previous versions, the CI was only evaluated using bootstrap
    # here, we fix such objects by calling with 0 bootstraps
    if(is.null(object[['tauQuantiles']])) {
      rep <- PP(z=NULL, pp=object$pp, bootstraps=0)  
    } else {
      rep <- PP(z=NULL, pp=object$pp, bootstraps=0, 
                tauQuantiles=object$tauQuantiles)
    }
    stats <- merge(stats, rep$stats[, list(tauQuantile, stat, outliers, CI)], 
                   by=c('tauQuantile', 'stat', 'outliers'))
  }
  #if(!is.null(stats[['CI']])) {
  stats[, CI.lower:=sapply(CI, function(.) .[1])]
  stats[, CI.upper:=sapply(CI, function(.) .[2])]
  stats[, CI:=NULL]
  # } else {
  #   # In previous versions, the CI was only evaluated using bootstrap
  #   # here, we fix such objects by calling with 0 bootstraps
  #   rep <- object$pp[, rAboot(i, idPair, z, bootstraps=0, as.dt=FALSE)]
  #   stats[, CI.lower:=NA]
  #   stats[, CI.upper:=NA]
  # }
  
  stats[, bCI.lower:=sapply(bCI, function(.) .[1])]
  stats[, bCI.upper:=sapply(bCI, function(.) .[2])]
  stats[, bCI:=NULL]
  
  stats[, filter:=factor(filter)]
  
  stats[, tips:=NULL]
  stats[, bSample:=NULL]
  stats[, n:=NULL]
  
  class(stats) <- c('summary.PP', class(stats))
  stats
}


#' A basic ggplot of a PP analysis
#' @param object an object of class 'PP' (see ?summary.PP)
#' @param tauQuantileType a character vector containing the types of quantiles
#' for which plots should be returned. If NA, all available types are plotted.
#' Accpetable types are c('V', 'D', 'O', 'qu', 'Q', 'M', 'A'), corresponding to 
#' the following fractions: c(0.05, 0.1, 0.125, 0.2, 0.25, 0.5, 1).
#' 
#' 
#' @export
plot.PP <- function(object, abs=TRUE,
                    tauQuantileType=c('V', 'D', 'O', 'qu', 'Q', 'M', 'A'),
                    mapping='aes(tau, deltaz)',
                    filter='TRUE',
                    facets=tauQuantileType~.,
                    ...) {
  pp <- copy(object$pp)
  pp[, zj:=z[match(j, i)]]
  
  if(!abs) {
    pp[, deltaz:=z-z[match(j, i)]]
  }
  pplong <- rbindlist(
    lapply(tauQuantileType, function(tqt) {
      tqttau <- paste0(tqt, 'tau')
      if(length(match(tqttau, names(pp)))==1) {
        colIds <- match(c('i', 'j', 'idPair', 'tau', 'z', 'zj', 'deltaz', 't', tqttau),
                        names(pp))
        res <- pp[, colIds, with=FALSE]
        setnames(res, tqttau, 'tauQuantile')
        res[, tauQuantileType:=factor(tqt, levels=tauQuantileType)]
        res[eval(parse(text=filter))]
      } else {
        NULL
      }
    })
  )
  res <- ggplot2::ggplot(data=pplong, eval(parse(text=mapping))) 
  if(!is.null(facets)) {
    print(class(facets))
    res <- res + ggplot2::facet_grid(facets)
  }
  
  
  res
}

#' A box-plot of phenotypic distances against phylogenetic distances from a PP
#' analysis
#' @param object An object of class PP.
#' @param abs Logical indicating whether to plot absolute phenotypic distances.
#' @param filter A character evaluating as an R expression. Defaults to TRUE.
#' @param mapping  A character string. Defaults to 
#' @param facets A formula passed to ggplot::facet_grid 'ggplot2::aes(tau, deltaz)'
#' 
#' @export
boxplot.PP <- function(object, abs=TRUE,
                       tauQuantileType=c('V', 'D', 'O', 'qu', 'Q', 'M', 'A'),
                       filter='TRUE',
                       mapping='ggplot2::aes(tau, deltaz)',
                       facets=tauQuantileType~.,
                       ...) {
  pp <- copy(object$pp)
  pp[, zj:=z[match(j, i)]]
  if(!abs) {
    pp[, deltaz:=z-z[match(j, i)]]
  }
  pplong <- rbindlist(
    lapply(tauQuantileType, function(tqt) {
      tqttau <- paste0(tqt, 'tau')
      if(length(match(tqttau, names(pp)))==1) {
        colIds <- match(c('i', 'j', 'idPair', 'tau', 'z', 'deltaz', 't', tqttau),
                        names(pp))
        res <- pp[, colIds, with=FALSE]
        setnames(res, tqttau, 'tauQuantile')
        res[, tauQuantileType:=factor(tqt, levels=tauQuantileType)]
        res[eval(parse(text=filter))]
      } else {
        NULL
      }
    })
  )
  res <- ggplot2::ggplot(pplong, eval(parse(text=mapping))) + 
    ggplot2::geom_boxplot(aes(group=tauQuantile))
  
  if(!is.null(facets)) {
    res <- res + ggplot2::facet_grid(facets)
  }
  res
}

#' Plot the summary of a PP analysis
#' 
#' @export
plot.summary.PP <- function(object, statistic='rA', 
                            tauQuantileType=NA, 
                            outliers=NA,
                            filter='TRUE',
                            CI='bootstrap',
                            facets=tauQuantileType~withOutliers) {
  summ <- object[stat==statistic[[1]]]
  tqt <- tauQuantileType
  outl <- outliers
  if(!is.na(tqt)) {
    summ <- summ[as.character(tauQuantileType)%in%as.character(tqt)]
  }
  if(!is.na(outl)) {
    summ <- summ[outliers%in%outl]
  }
  summ <- summ[eval(parse(text=filter))]
  
  res <- ggplot2::ggplot(data=summ) + 
    ggplot2::geom_point(ggplot2::aes(x=tauMean, y=est))
  
  if(tolower(CI)=='bootstrap' & summ[, all(!is.na(bCI.lower))]) {
    res <- res + ggplot2::geom_segment(ggplot2::aes(x=tauMean, xend=tauMean, 
                                                    y=bCI.lower, yend=bCI.upper))
  } else {
    if(tolower(CI)=='bootstrap') {
      warning('No bootstrap CI available, using theoretical CI.')
    }
    res <- res + ggplot2::geom_segment(aes(x=tauMean, xend=tauMean, 
                                           y=CI.lower, yend=CI.upper))
  }
  
  if(!is.null(facets)) {
    res <- res + ggplot2::facet_grid(facets)
  }
  
  res
}

#' Scatter plot of phylogenetic pairs
#' @param z numeric vector of phenotypes
#' @param tree a phylo object with tip-labels corresponding to the entries in z
#' @param ppAnalysis a list resulting from a call to analyseCPPs on the same tree and z.
#' @param CPPthr numeric indicating the maximum phylogenetic distance separating a 
#' closest phylogenetic pair
#' @param ruleOutXIQR numeric a multiplier used to define outlier CPPs as defined in 
#' the referenced article.
#' @param zName,treeName characters used when the parameter z is a list; indicate the
#' corresponding names in the list
#' @param xlim,ylim,xlab,ylab graphical parameters passed to plot
#' 
#' @import data.table 
#' 
#' @export
scatterPlotPPs <- function(z, tree, ppAnalysis, CPPthr=10^-4, ruleOutXIQR=1.5, zName='z', treeName='tree', xlab=expression(lg(tau)~"[lg(subst. per site)]"), ylab=expression(group("|",Delta~lg(spVL),"|")),  xlim=c(-6,0), ylim=c(0,5)) {
  if(is.list(z)) {
    p <- z
    z <- p[[zName]]
    if(is.null(z)) {
      z <- p[['v']]
    }
    tree <- p[[treeName]]
    
    if(is.null(z)|is.null(tree)) {
      stop('If a list is supplied as argument z, this list should contain a vector of trait values named "z" or zName and a phylo-object named "tree" or treeName')
    }
  }
  N <- length(tree$tip.label)
  rootTipDists <- nodeTimes(tree)[1:N]
  pp <- ppAnalysis$pp
  pp[, dRoot:=rootTipDists[i]]
  zDists <- ppAnalysis$zDists
  tipDists <- ppAnalysis$tipDists
  
  s <- sample(x=1:length(zDists), size=nrow(pp), replace=FALSE)
  
  plot(x=log10(tipDists[s]), y=zDists[s], type='p', pch=20, cex=0.25, col=adjustcolor('darkgrey', alpha.f=0.3), 
       xlab=xlab, ylab=ylab, 
       xlim=xlim, ylim=ylim)
  pp[, points(x=log10(d), y=deltaz, pch=20, cex=0.25, col=adjustcolor('darkgreen', alpha.f=0.3))]
  pp[tau<=CPPthr, points(x=log10(d), y=deltaz, pch=20, cex=0.25, col=adjustcolor('magenta', alpha.f=0.3))]
  pp[tau<=CPPthr & 
       deltaz>{
         q=quantile(unique(deltaz[tau<=CPPthr])); q[4]+ruleOutXIQR*(q[4]-q[2])}, 
     points(x=log10(d), y=deltaz, col='blue', pch=20, cex=0.4)]
}


#' Box plots of trait values along a tree
#' @param nGroups integer the number of groups
#' @param ... additional parameters passed to boxplot
#' 
#' @import data.table
#' 
#' @export
boxplotTraitAlongTree <- function(z, tree, nGroups=15, ...) {
  groups <- groupByRootDist(tree, nGroups=nGroups)
  midDistPoints <- groups$groupMeans
  rootTipDistGroups <- groups$rootTipDistGroups
  boxes <- lapply(midDistPoints, function(.) c())

  for(i in 1:length(rootTipDistGroups)) {
    boxes[[as.character(rootTipDistGroups[[i]])]] <-
      c(boxes[[as.character(rootTipDistGroups[[i]])]], z[i])
  }

  boxes <- boxes[sort(names(boxes))]
  names(boxes) <- as.character(midDistPoints)
  
  boxes <- lapply(boxes, function(.) as.numeric(.))

  params <- list(...)
  myParams <- list(varwidth=TRUE, 
                   names=names(boxes), cex=.4, border='grey40',
                   at=as.numeric(names(boxes)), 
                   main='', 
                   xlab='root-tip distance [subst. per site]',
                   ylab=expression(lg(spVL)))
  
  params <- c(params, myParams[setdiff(names(myParams), names(params))])
  
  do.call(boxplot, c(list(boxes), params))
}
